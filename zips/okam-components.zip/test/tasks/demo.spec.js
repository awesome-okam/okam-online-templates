/**
 * @file test
 * @author ${author}
 */

'use strict';

const assert = require('assert');

describe('test: demo', function () {
    it('1+1', function () {
        assert(1 + 1 === 2);
    });
});
