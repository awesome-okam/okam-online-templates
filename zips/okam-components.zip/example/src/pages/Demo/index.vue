<template>
    <view class="home-wrap">
    </view>
</template>
<script>
export default {
    config: {
        title: 'components'
    },

    components: {
    },

    data: {
        value: ''
    },

    methods: {

    }
};
</script>
<style lang="stylus">
.content
    margin: 0
    padding: 0
</style>

