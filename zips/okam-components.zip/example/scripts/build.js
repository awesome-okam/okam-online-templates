/**
 * @file Build script
 * @author ${author}
 */

'use strict';

const build = require('okam-build');
build.run();
