/**
 * @file Build script
 * @author
 */

'use strict';

const build = require('okam-build');
build.run();
